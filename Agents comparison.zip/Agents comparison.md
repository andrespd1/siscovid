```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
city = 'cartagena'
```


```python
series1 = pd.read_csv( './data/agents/clean/{}-1.csv'.format( city ) )
series2 = pd.read_csv( './data/agents/clean/{}-2.csv'.format( city ) )
series3 = pd.read_csv( './data/agents/clean/{}-3.csv'.format( city ) )
series4 = pd.read_csv( './data/agents/clean/{}-4.csv'.format( city ) )
```


```python
series1[ 'Fecha' ] = pd.to_datetime( series1[ 'Fecha' ] )
series2[ 'Fecha' ] = pd.to_datetime( series2[ 'Fecha' ] )
series3[ 'Fecha' ] = pd.to_datetime( series3[ 'Fecha' ] )
series4[ 'Fecha' ] = pd.to_datetime( series4[ 'Fecha' ] )
```


```python
series1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>exp</th>
      <th>Fecha</th>
      <th>Graves</th>
      <th>Críticos</th>
      <th>Fallecidos</th>
      <th>R0</th>
      <th>Rt</th>
      <th>Cuarentena</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>2020-03-06</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>2020-03-07</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.000135</td>
      <td>0.285714</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>2020-03-08</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.000788</td>
      <td>0.521277</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>2020-03-09</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.001374</td>
      <td>0.625000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>2020-03-10</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.001982</td>
      <td>0.727273</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
def ci( x ):
    try:
        return 1.96 * np.std( x ) / np.sqrt( len( x ) )
    except ZeroDivisionError:
        return 0
```


```python
series1_grouped = series1.groupby( 'Fecha' ).agg( { 'Graves': [ 'mean', ci ], 'Críticos': [ 'mean', ci ], 'Fallecidos': [ 'mean', ci ], 'R0': [ 'mean', ci ], 'Rt': [ 'mean', ci ], 'Cuarentena': [ 'mean' ] } )
series1_grouped.columns = [ '_'.join( col ).strip() for col in series1_grouped.columns.values ]
```


```python
series2_grouped = series2.groupby( 'Fecha' ).agg( { 'Graves': [ 'mean', ci ], 'Críticos': [ 'mean', ci ], 'Fallecidos': [ 'mean', ci ], 'R0': [ 'mean', ci ], 'Rt': [ 'mean', ci ], 'Cuarentena': [ 'mean' ] } )
series2_grouped.columns = [ '_'.join( col ).strip() for col in series2_grouped.columns.values ]
```


```python
series3_grouped = series3.groupby( 'Fecha' ).agg( { 'Graves': [ 'mean', ci ], 'Críticos': [ 'mean', ci ], 'Fallecidos': [ 'mean', ci ], 'R0': [ 'mean', ci ], 'Rt': [ 'mean', ci ], 'Cuarentena': [ 'mean' ] } )
series3_grouped.columns = [ '_'.join( col ).strip() for col in series3_grouped.columns.values ]
```


```python
series4_grouped = series4.groupby( 'Fecha' ).agg( { 'Graves': [ 'mean', ci ], 'Críticos': [ 'mean', ci ], 'Fallecidos': [ 'mean', ci ], 'R0': [ 'mean', ci ], 'Rt': [ 'mean', ci ], 'Cuarentena': [ 'mean' ] } )
series4_grouped.columns = [ '_'.join( col ).strip() for col in series4_grouped.columns.values ]
```


```python
series1_grouped.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Graves_mean</th>
      <th>Graves_ci</th>
      <th>Críticos_mean</th>
      <th>Críticos_ci</th>
      <th>Fallecidos_mean</th>
      <th>Fallecidos_ci</th>
      <th>R0_mean</th>
      <th>R0_ci</th>
      <th>Rt_mean</th>
      <th>Rt_ci</th>
      <th>Cuarentena_mean</th>
    </tr>
    <tr>
      <th>Fecha</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2020-09-17</th>
      <td>0.000262</td>
      <td>0.000027</td>
      <td>0.000032</td>
      <td>0.000008</td>
      <td>0.000142</td>
      <td>0.000022</td>
      <td>0.464071</td>
      <td>0.002014</td>
      <td>0.304202</td>
      <td>0.009247</td>
      <td>0.559322</td>
    </tr>
    <tr>
      <th>2020-09-18</th>
      <td>0.000257</td>
      <td>0.000027</td>
      <td>0.000033</td>
      <td>0.000009</td>
      <td>0.000142</td>
      <td>0.000022</td>
      <td>0.464651</td>
      <td>0.002003</td>
      <td>0.302434</td>
      <td>0.007471</td>
      <td>0.605495</td>
    </tr>
    <tr>
      <th>2020-09-19</th>
      <td>0.000250</td>
      <td>0.000023</td>
      <td>0.000034</td>
      <td>0.000010</td>
      <td>0.000143</td>
      <td>0.000022</td>
      <td>0.465255</td>
      <td>0.001995</td>
      <td>0.323587</td>
      <td>0.008900</td>
      <td>0.543470</td>
    </tr>
    <tr>
      <th>2020-09-20</th>
      <td>0.000253</td>
      <td>0.000022</td>
      <td>0.000036</td>
      <td>0.000010</td>
      <td>0.000144</td>
      <td>0.000022</td>
      <td>0.465936</td>
      <td>0.001959</td>
      <td>0.330585</td>
      <td>0.009581</td>
      <td>0.548394</td>
    </tr>
    <tr>
      <th>2020-09-21</th>
      <td>0.000248</td>
      <td>0.000022</td>
      <td>0.000032</td>
      <td>0.000010</td>
      <td>0.000144</td>
      <td>0.000022</td>
      <td>0.466662</td>
      <td>0.001925</td>
      <td>0.321321</td>
      <td>0.008748</td>
      <td>0.550224</td>
    </tr>
  </tbody>
</table>
</div>




```python
fig, ax = plt.subplots( figsize = ( 20, 7 ) )

ax.plot( series1_grouped.index, series1_grouped[ 'Graves_mean' ], label = 'Escenario 1' )
ax.fill_between( series1_grouped.index, ( series1_grouped[ 'Graves_mean' ] - series1_grouped[ 'Graves_ci' ] ), ( series1_grouped[ 'Graves_mean' ] + series1_grouped[ 'Graves_ci' ] ), alpha = .1 )

ax.plot( series2_grouped.index, series2_grouped[ 'Graves_mean' ], label = 'Escenario 2' )
ax.fill_between( series2_grouped.index, ( series2_grouped[ 'Graves_mean' ] - series2_grouped[ 'Graves_ci' ] ), ( series2_grouped[ 'Graves_mean' ] + series2_grouped[ 'Graves_ci' ] ), alpha = .1 )

ax.plot( series3_grouped.index, series3_grouped[ 'Graves_mean' ], label = 'Escenario 3' )
ax.fill_between( series3_grouped.index, ( series3_grouped[ 'Graves_mean' ] - series3_grouped[ 'Graves_ci' ] ), ( series3_grouped[ 'Graves_mean' ] + series3_grouped[ 'Graves_ci' ] ), alpha = .1 )

ax.plot( series4_grouped.index, series4_grouped[ 'Graves_mean' ], label = 'Escenario 4' )
ax.fill_between( series4_grouped.index, ( series4_grouped[ 'Graves_mean' ] - series4_grouped[ 'Graves_ci' ] ), ( series4_grouped[ 'Graves_mean' ] + series4_grouped[ 'Graves_ci' ] ), alpha = .1 )

ax.set_yticklabels( [ '{:,.3%}'.format( x ) for x in ax.get_yticks() ] )

plt.title( 'Comparación de Graves' )
plt.xlabel( 'Fecha' )
plt.ylabel( 'Casos' )
plt.grid( True )
plt.legend()
```




    <matplotlib.legend.Legend at 0x7fa43372cc50>




![png](output_11_1.png)



```python
fig, ax = plt.subplots( figsize = ( 20, 7 ) )

ax.plot( series1_grouped.index, series1_grouped[ 'Críticos_mean' ], label = 'Escenario 1' )
ax.fill_between( series1_grouped.index, ( series1_grouped[ 'Críticos_mean' ] - series1_grouped[ 'Críticos_ci' ] ), ( series1_grouped[ 'Críticos_mean' ] + series1_grouped[ 'Críticos_ci' ] ), alpha = .1 )

ax.plot( series2_grouped.index, series2_grouped[ 'Críticos_mean' ], label = 'Escenario 2' )
ax.fill_between( series2_grouped.index, ( series2_grouped[ 'Críticos_mean' ] - series2_grouped[ 'Críticos_ci' ] ), ( series2_grouped[ 'Críticos_mean' ] + series2_grouped[ 'Críticos_ci' ] ), alpha = .1 )

ax.plot( series3_grouped.index, series3_grouped[ 'Críticos_mean' ], label = 'Escenario 3' )
ax.fill_between( series3_grouped.index, ( series3_grouped[ 'Críticos_mean' ] - series3_grouped[ 'Críticos_ci' ] ), ( series3_grouped[ 'Críticos_mean' ] + series3_grouped[ 'Críticos_ci' ] ), alpha = .1 )

ax.plot( series4_grouped.index, series4_grouped[ 'Críticos_mean' ], label = 'Escenario 4' )
ax.fill_between( series4_grouped.index, ( series4_grouped[ 'Críticos_mean' ] - series4_grouped[ 'Críticos_ci' ] ), ( series4_grouped[ 'Críticos_mean' ] + series4_grouped[ 'Críticos_ci' ] ), alpha = .1 )

ax.set_yticklabels( [ '{:,.3%}'.format( x ) for x in ax.get_yticks() ] )

plt.title( 'Comparación de Críticos' )
plt.xlabel( 'Fecha' )
plt.ylabel( 'Casos' )
plt.grid( True )
plt.legend()
```




    <matplotlib.legend.Legend at 0x7fa433cc85d0>




![png](output_12_1.png)



```python
fig, ax = plt.subplots( figsize = ( 20, 7 ) )

ax.plot( series1_grouped.index, series1_grouped[ 'Fallecidos_mean' ], label = 'Escenario 1' )
ax.fill_between( series1_grouped.index, ( series1_grouped[ 'Fallecidos_mean' ] - series1_grouped[ 'Fallecidos_ci' ] ), ( series1_grouped[ 'Fallecidos_mean' ] + series1_grouped[ 'Fallecidos_ci' ] ), alpha = .1 )

ax.plot( series2_grouped.index, series2_grouped[ 'Fallecidos_mean' ], label = 'Escenario 2' )
ax.fill_between( series2_grouped.index, ( series2_grouped[ 'Fallecidos_mean' ] - series2_grouped[ 'Fallecidos_ci' ] ), ( series2_grouped[ 'Fallecidos_mean' ] + series2_grouped[ 'Fallecidos_ci' ] ), alpha = .1 )

ax.plot( series3_grouped.index, series3_grouped[ 'Fallecidos_mean' ], label = 'Escenario 3' )
ax.fill_between( series3_grouped.index, ( series3_grouped[ 'Fallecidos_mean' ] - series3_grouped[ 'Fallecidos_ci' ] ), ( series3_grouped[ 'Fallecidos_mean' ] + series3_grouped[ 'Fallecidos_ci' ] ), alpha = .1 )

ax.plot( series4_grouped.index, series4_grouped[ 'Fallecidos_mean' ], label = 'Escenario 4' )
ax.fill_between( series4_grouped.index, ( series4_grouped[ 'Fallecidos_mean' ] - series4_grouped[ 'Fallecidos_ci' ] ), ( series4_grouped[ 'Fallecidos_mean' ] + series4_grouped[ 'Fallecidos_ci' ] ), alpha = .1 )

ax.set_yticklabels( [ '{:,.3%}'.format( x ) for x in ax.get_yticks() ] )

plt.title( 'Comparación de Fallecidos' )
plt.xlabel( 'Fecha' )
plt.ylabel( 'Casos' )
plt.grid( True )
plt.legend()
```




    <matplotlib.legend.Legend at 0x7fa4334bd150>




![png](output_13_1.png)



```python
fig, ax = plt.subplots( figsize = ( 20, 7 ) )

ax.plot( series1_grouped.index, series1_grouped[ 'R0_mean' ], label = 'Escenario 1' )
ax.fill_between( series1_grouped.index, ( series1_grouped[ 'R0_mean' ] - series1_grouped[ 'R0_ci' ] ), ( series1_grouped[ 'R0_mean' ] + series1_grouped[ 'R0_ci' ] ), alpha = .1 )

ax.plot( series2_grouped.index, series2_grouped[ 'R0_mean' ], label = 'Escenario 2' )
ax.fill_between( series2_grouped.index, ( series2_grouped[ 'R0_mean' ] - series2_grouped[ 'R0_ci' ] ), ( series2_grouped[ 'R0_mean' ] + series2_grouped[ 'R0_ci' ] ), alpha = .1 )

ax.plot( series3_grouped.index, series3_grouped[ 'R0_mean' ], label = 'Escenario 3' )
ax.fill_between( series3_grouped.index, ( series3_grouped[ 'R0_mean' ] - series3_grouped[ 'R0_ci' ] ), ( series3_grouped[ 'R0_mean' ] + series3_grouped[ 'R0_ci' ] ), alpha = .1 )

ax.plot( series4_grouped.index, series4_grouped[ 'R0_mean' ], label = 'Escenario 4' )
ax.fill_between( series4_grouped.index, ( series4_grouped[ 'R0_mean' ] - series4_grouped[ 'R0_ci' ] ), ( series4_grouped[ 'R0_mean' ] + series4_grouped[ 'R0_ci' ] ), alpha = .1 )

ax.set_yticklabels( [ '{:,.0%}'.format( x ) for x in ax.get_yticks() ] )

plt.title( 'Comparación de R0' )
plt.xlabel( 'Fecha' )
plt.ylabel( 'R0' )
plt.grid( True )
plt.legend()
```




    <matplotlib.legend.Legend at 0x7fa43557df50>




![png](output_14_1.png)



```python
fig, ax = plt.subplots( figsize = ( 20, 7 ) )

ax.plot( series1_grouped.index, series1_grouped[ 'Rt_mean' ], label = 'Escenario 1' )
ax.fill_between( series1_grouped.index, ( series1_grouped[ 'Rt_mean' ] - series1_grouped[ 'Rt_ci' ] ), ( series1_grouped[ 'Rt_mean' ] + series1_grouped[ 'Rt_ci' ] ), alpha = .1 )

ax.plot( series2_grouped.index, series2_grouped[ 'Rt_mean' ], label = 'Escenario 2' )
ax.fill_between( series2_grouped.index, ( series2_grouped[ 'Rt_mean' ] - series2_grouped[ 'Rt_ci' ] ), ( series2_grouped[ 'Rt_mean' ] + series2_grouped[ 'Rt_ci' ] ), alpha = .1 )

ax.plot( series3_grouped.index, series3_grouped[ 'Rt_mean' ], label = 'Escenario 3' )
ax.fill_between( series3_grouped.index, ( series3_grouped[ 'Rt_mean' ] - series3_grouped[ 'Rt_ci' ] ), ( series3_grouped[ 'Rt_mean' ] + series3_grouped[ 'Rt_ci' ] ), alpha = .1 )

ax.plot( series4_grouped.index, series4_grouped[ 'Rt_mean' ], label = 'Escenario 4' )
ax.fill_between( series4_grouped.index, ( series4_grouped[ 'Rt_mean' ] - series4_grouped[ 'Rt_ci' ] ), ( series4_grouped[ 'Rt_mean' ] + series4_grouped[ 'Rt_ci' ] ), alpha = .1 )

ax.set_yticklabels( [ '{:,.0%}'.format( x ) for x in ax.get_yticks() ] )

plt.title( 'Comparación de Rt' )
plt.xlabel( 'Fecha' )
plt.ylabel( 'Rt' )
plt.grid( True )
plt.legend()
```




    <matplotlib.legend.Legend at 0x7fa4355ecd10>




![png](output_15_1.png)



```python
fig, ax = plt.subplots( figsize = ( 20, 7 ) )

ax.plot( series1_grouped.index, series1_grouped[ 'Cuarentena_mean' ], label = 'Escenario 1' )

ax.plot( series2_grouped.index, series2_grouped[ 'Cuarentena_mean' ], label = 'Escenario 2' )

ax.plot( series3_grouped.index, series3_grouped[ 'Cuarentena_mean' ], label = 'Escenario 3' )

ax.plot( series4_grouped.index, series4_grouped[ 'Cuarentena_mean' ], label = 'Escenario 4' )

ax.set_yticklabels( [ '{:,.0%}'.format( x ) for x in ax.get_yticks() ] )

plt.title( 'Comparación de Cuarentena' )
plt.xlabel( 'Fecha' )
plt.ylabel( '% Cuarentena_mean' )
plt.grid( True )
plt.legend()
```




    <matplotlib.legend.Legend at 0x7fa4358b5f10>




![png](output_16_1.png)



```python

```
